package it.uniroma3.siw.progetto.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import it.uniroma3.siw.progetto.model.Project;
import it.uniroma3.siw.progetto.model.User;

@Repository
public interface ProjectRepository extends CrudRepository<Project, Long> {

	public List<Project> findByMembers(User user);
	
	public List<Project> findByOwner(User owner);
	
}
