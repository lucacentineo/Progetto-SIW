package it.uniroma3.siw.progetto.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.progetto.model.Project;
import it.uniroma3.siw.progetto.model.Tag;
import it.uniroma3.siw.progetto.model.Task;
import it.uniroma3.siw.progetto.model.User;
import it.uniroma3.siw.progetto.repository.TagRepository;
import it.uniroma3.siw.progetto.repository.TaskRepository;
import it.uniroma3.siw.progetto.repository.UserRepository;

@Service
public class TaskService {

	@Autowired
	protected TaskRepository taskRepository;
	
	@Autowired
	protected TagRepository tagRepository;
	
	@Autowired
	protected UserRepository userRepository;
	
	@Transactional
	public Task getTask(Long id) {
		Optional<Task> result = this.taskRepository.findById(id);
		return result.orElse(null);
	}
	
	@Transactional
	public Task saveTask(Task task) {
		return this.taskRepository.save(task);
	}
	
	@Transactional
	public Task setCompleted(Task task) {
		task.setCompleted(true);
		return this.taskRepository.save(task);
	}
	
	@Transactional
    public Task saveTag(Tag tag,Task task) {
        this.tagRepository.save(tag);
        task.addtag(tag);
        return this.saveTask(task);
    }
	
    @Transactional
    public Task saveUser(User user,Task task) {
       
        user.addTask(task);
        this.userRepository.save(user);
       
        return this.saveTask(task);
       
    }
	
	
	@Transactional
	public void deleteTask(Task task) {
		this.taskRepository.delete(task);
	}
}
