package it.uniroma3.siw.progetto.controller;

import it.uniroma3.siw.progetto.controller.session.SessionData;
import it.uniroma3.siw.progetto.controller.validation.UserValidator;
import it.uniroma3.siw.progetto.model.Credentials;
import it.uniroma3.siw.progetto.model.User;
import it.uniroma3.siw.progetto.repository.UserRepository;
import it.uniroma3.siw.progetto.service.CredentialsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UserController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserValidator userValidator;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    SessionData sessionData;
    
    @Autowired
    CredentialsService credentialsService;

    
    @RequestMapping(value = { "/home" }, method = RequestMethod.GET)
    public String home(Model model) {
        User loggedUser = sessionData.getLoggedUser();
        model.addAttribute("user", loggedUser);
        return "home";
    }

    @RequestMapping(value = { "/users/me" }, method = RequestMethod.GET)
    public String me(Model model) {
        User loggedUser = sessionData.getLoggedUser();
        Credentials credentials = sessionData.getLoggedCredentials();
        System.out.println(credentials.getPassword());
        model.addAttribute("user", loggedUser);
        model.addAttribute("credentials", credentials);

        return "userProfile";
    }

    @RequestMapping(value = { "/admin" }, method = RequestMethod.GET)
    public String admin(Model model) {
        User loggedUser = sessionData.getLoggedUser();
        model.addAttribute("user", loggedUser);
        return "admin";
    }
    
    @RequestMapping(value= {"/editFirstName"}, method = RequestMethod.GET)
    public String showEditFirstNameForm(Model model) {
        model.addAttribute("user", sessionData.getLoggedUser());
       
        return "editFirstName";
    }
  
    @RequestMapping(value= {"/editFirstName"}, method = RequestMethod.POST)
    public String editUserFirstName( Model model, @ModelAttribute("firstName")String firstName) {
        Credentials credentials = sessionData.getLoggedCredentials();
        credentials.getUser().setFirstName(firstName);
        credentialsService.saveCredentials(credentials);
        model.addAttribute("user", sessionData.getLoggedUser());
        return "home";
    }
    
    @RequestMapping(value= {"/editLastName"}, method = RequestMethod.GET)
    public String showEditLastNameForm(Model model) {
        model.addAttribute("user", sessionData.getLoggedUser());
       
        return "editLastName";
    }
  
    @RequestMapping(value= {"/editLastName"}, method = RequestMethod.POST)
    public String editUserLastName( Model model, @ModelAttribute("lastName")String lastName) {
        Credentials credentials = sessionData.getLoggedCredentials();
        credentials.getUser().setLastName(lastName);
        credentialsService.saveCredentials(credentials);
        model.addAttribute("user", sessionData.getLoggedUser());
        return "home";
    }
    
}
