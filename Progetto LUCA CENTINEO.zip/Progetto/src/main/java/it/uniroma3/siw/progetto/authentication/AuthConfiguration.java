package it.uniroma3.siw.progetto.authentication;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import javax.sql.DataSource;

import static it.uniroma3.siw.progetto.model.Credentials.ADMIN_ROLE;


@Configuration
@EnableWebSecurity
public class AuthConfiguration extends WebSecurityConfigurerAdapter {
	
    @Autowired
    DataSource datasource;
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                
                .authorizeRequests()
                /* anyone (authenticated or not) can access the welcome page, the login page, and the registration page*/
                
                .antMatchers(HttpMethod.GET, "/stile.css").permitAll()
                
                .antMatchers(HttpMethod.GET, "/", "/index", "/login", "/users/register").permitAll()
                /* anyone (authenticated or not) can send POST requests to the login end-point and the register end-point */
                
                .antMatchers(HttpMethod.POST, "/login", "/users/register").permitAll()
                /* only authenticated users with ADMIN authority can access the admin-page */
                
                .antMatchers(HttpMethod.GET, "/admin").hasAnyAuthority(ADMIN_ROLE)
                /*all authenticated users can access all the remaining other pages */
                
                .anyRequest().authenticated().and().formLogin().defaultSuccessUrl("/home")
                .and().logout().logoutUrl("/logout").logoutSuccessUrl("/index"); 
    }

    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.jdbcAuthentication().dataSource(this.datasource)
                .authoritiesByUsernameQuery("SELECT username, role FROM credentials WHERE username=?")
                .usersByUsernameQuery("SELECT username, password, 1 as enabled FROM credentials WHERE username=?");
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
}