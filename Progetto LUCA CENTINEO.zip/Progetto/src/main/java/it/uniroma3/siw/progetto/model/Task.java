package it.uniroma3.siw.progetto.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.*;

@Entity
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = false, length=100)
	private String name;

	@Column(nullable = false, length=100)
	private String description;

	@Column(nullable = false)
	private boolean completed;

	@Column (updatable = false, nullable = false)
	private LocalDateTime creationTimeStamp;

	@Column (nullable = false)
	private LocalDateTime lastUpdateTimeStamp;

	@ManyToMany
	private List<Tag> tags;

	@ManyToOne
	private User userTask;

	public Task() {
		this.tags = new ArrayList<>();
	}

	public Task(String name, String description, Boolean completed) {
		this();
		this.name=name;
		this.description=description;
		this.completed=completed;
	}

	@PrePersist
	protected void Persist() {
		this.creationTimeStamp = LocalDateTime.now();
		this.lastUpdateTimeStamp = LocalDateTime.now();
	}

	@PreUpdate
	protected void Update() {
		this.lastUpdateTimeStamp = LocalDateTime.now();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public LocalDateTime getCreationTimeStamp() {
		return creationTimeStamp;
	}

	public void setCreationTimeStamp(LocalDateTime creationTimeStamp) {
		this.creationTimeStamp = creationTimeStamp;
	}



	public LocalDateTime getLastUpdateTimeStamp() {
		return lastUpdateTimeStamp;
	}

	public void setLastUpdateTimeStamp(LocalDateTime lastUpdateTimeStamp) {
		this.lastUpdateTimeStamp = lastUpdateTimeStamp;
	}

	public void addtag(Tag tag) {
		this.tags.add(tag);
	}


	public List<Tag> getTags() {
		return tags;
	}

	public void setTags(List<Tag> tags) {
		this.tags = tags;
	}

	public User getUserTask() {
		return userTask;
	}




	public void setUserTask(User userTask) {
		this.userTask = userTask;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Task task = (Task) o;
		return completed == task.completed &&
				Objects.equals(name, task.name) &&
				Objects.equals(creationTimeStamp, task.creationTimeStamp) &&
				Objects.equals(lastUpdateTimeStamp, task.lastUpdateTimeStamp);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, completed, creationTimeStamp, lastUpdateTimeStamp);
	}

}
