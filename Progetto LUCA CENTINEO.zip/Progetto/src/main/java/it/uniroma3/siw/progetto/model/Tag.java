package it.uniroma3.siw.progetto.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Tag {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable = false, length=100)
	
	private String nome;
	
	@Column(nullable = false, length=100)
	
	private String descrizione;
	
	
	private String colore;
	
	
	@ManyToMany(mappedBy = "tags")
	private List<Task> tasks;
	
	public Tag() {
		this.tasks = new ArrayList<>();
	}
	
	public Tag(String nome, String colore, String descrizione) {
		this();
		this.nome = nome;
		this.colore = colore;
		this.descrizione = descrizione;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getColore() {
		return colore;
	}

	public void setColore(String colore) {
		this.colore = colore;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	
}

