package it.uniroma3.siw.progetto.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.uniroma3.siw.progetto.model.Project;
import it.uniroma3.siw.progetto.model.Tag;
import it.uniroma3.siw.progetto.model.Task;
import it.uniroma3.siw.progetto.model.User;
import it.uniroma3.siw.progetto.repository.ProjectRepository;
import it.uniroma3.siw.progetto.repository.TagRepository;

@Service
public class ProjectService {
	
	@Autowired
	protected ProjectRepository projectRepository;
	
	@Autowired
	protected TagRepository tagRepository;

	
	@Transactional
	public Project getProject(Long id) {
		Optional<Project> result = this.projectRepository.findById(id);
		return result.orElse(null);
	}
	
	@Transactional
	public Project saveProject(Project project) {
		return this.projectRepository.save(project);
	}
	
	@Transactional
    public Project saveTask(Task task,Project project) {
        project.addTask(task);
        return this.saveProject(project);
    }
	
	@Transactional
    public Project saveTag(Tag tag,Project project) {
        this.tagRepository.save(tag);
        project.addTag(tag);
        return this.saveProject(project);
    }
	
	@Transactional
	public void deleteProject(Project project) {
		this.projectRepository.delete(project);
	}
	
	@Transactional
    public void deleteProject(Long projectId) {
        this.projectRepository.delete(this.getProject(projectId));
    }
	
	@Transactional
	public Project shareProjectWithUser(Project project, User user) {
		project.addMember(user);  
		return this.projectRepository.save(project);
	}
	
    @Transactional
    public List<Project> retrieveProjectsOwnedBy(User user){
    	Iterable<Project> iterable = this.projectRepository.findByOwner(user);
    	ArrayList<Project> result = new ArrayList<>();
    	for(Project project : iterable) {
    		result.add(project);
    	}
    	return result;
    }
    
    @Transactional
    public List<Project> retrieveVisibleProjects(User user){
    	Iterable<Project> iterable = this.projectRepository.findByMembers(user);
    	ArrayList<Project> result = new ArrayList<>();
    	for(Project project : iterable) {
    		result.add(project);
    	}
    	return result;
    }
    
}
