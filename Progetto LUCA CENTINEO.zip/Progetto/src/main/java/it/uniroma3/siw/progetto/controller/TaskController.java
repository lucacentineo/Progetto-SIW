package it.uniroma3.siw.progetto.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.progetto.controller.session.SessionData;
import it.uniroma3.siw.progetto.model.Project;
import it.uniroma3.siw.progetto.model.Tag;
import it.uniroma3.siw.progetto.model.Task;
import it.uniroma3.siw.progetto.model.User;
import it.uniroma3.siw.progetto.service.ProjectService;
import it.uniroma3.siw.progetto.service.TaskService;
import it.uniroma3.siw.progetto.service.UserService;


@Controller
public class TaskController {

	@Autowired
	SessionData sessionData;

	@Autowired
	private  TaskService taskService;
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private UserService userService;


	@RequestMapping(value= {"/addTask/{projectId}"}, method=RequestMethod.GET)
	public String createTask(Model model,@PathVariable Long projectId) {

		Project project=this.projectService.getProject(projectId);

		model.addAttribute("project",project);
		model.addAttribute("taskForm",new Task());
		
		return  "addTask";
	}

	@RequestMapping(value= {"/addTask/{projectId}"}, method=RequestMethod.POST)
	public String createTaskForm(@ModelAttribute("taskForm")Task task,
			Model model,@ModelAttribute("nameTask")String nome,
			@ModelAttribute("descriptionTask")String descrizione,
			@PathVariable Long projectId) {

		Project project = this.projectService.getProject(projectId);

		task.setName(nome);
		task.setDescription(descrizione);
		this.projectService.saveTask(task,project);

		model.addAttribute("user",sessionData.getLoggedUser());

		return "redirect:/projects";
	}


	@RequestMapping(value= {"/deleteTask/{taskId}"},method=RequestMethod.POST)
	public String removeTask(Model model, @PathVariable Long taskId) {

		Task task = this.taskService.getTask(taskId);
		this.taskService.deleteTask(task);
		model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
		
		return "projects";
	}
	
	
	@RequestMapping(value= {"/editTaskName/{taskId}"}, method=RequestMethod.GET)
	public String editTaskName(Model model,@PathVariable Long taskId) {

		Task task=this.taskService.getTask(taskId);
		model.addAttribute("task",task);

		return "editTaskName";
	}



	@RequestMapping(value= {"/editTaskName/{taskId}"}, method=RequestMethod.POST)
	public String editTaskNameForm(Model model,@PathVariable Long taskId,
			@ModelAttribute("newName")String nome) {

		Task task = this.taskService.getTask(taskId);
		task.setName(nome);
		this.taskService.saveTask(task);
		model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));

		return "redirect:/projects";

	}

	@RequestMapping(value= {"/editTaskDescription/{taskId}"}, method=RequestMethod.GET)
	public String editTaskDescription(Model model,@PathVariable Long taskId) {

		Task task=this.taskService.getTask(taskId);
		model.addAttribute("task",task);

		return "editTaskDescription";
	}

	@RequestMapping(value= {"/editTaskDescription/{taskId}"}, method=RequestMethod.POST)
	public String editTaskDescriptionForm(Model model,@PathVariable Long taskId,
			@ModelAttribute("newDescription")String descrizione) {

		Task task=this.taskService.getTask(taskId);
		task.setDescription(descrizione);
		this.taskService.saveTask(task);
		model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));

		return "redirect:/projects";

	}
	
	  @RequestMapping(value= {"/addTagOnTasks/{taskId}"}, method=RequestMethod.GET)
	    public String createTag(Model model,@PathVariable Long taskId) {

	 

	        Task task=this.taskService.getTask(taskId);

	 

	        model.addAttribute("task", task);
	        model.addAttribute("tagForm", new Tag());
	        
	        return  "addTagOnTasks";
	    }
	    
	    @RequestMapping(value= {"/addTagOnTasks/{taskId}"}, method=RequestMethod.POST)
	    public String createTagForm(@ModelAttribute("tagForm")Tag tag,
	            Model model,@ModelAttribute("nameTag")String nome,
	            @ModelAttribute("descriptionTag")String descrizione,
	            @ModelAttribute("colorTag")String colore,
	            @PathVariable Long taskId) {

	 

	    	Task task=this.taskService.getTask(taskId);

	 

	        tag.setNome(nome);
	        tag.setDescrizione(descrizione);
	        tag.setColore(colore);
	        this.taskService.saveTag(tag, task);

	 

	        model.addAttribute("user",sessionData.getLoggedUser());

	 

	        return "redirect:/projects";
	    }
	    
	    @RequestMapping(value= {"/assegnaTask/{taskId}/{projectId}/{userMemberId}"},method=RequestMethod.POST)
	    public String ViewTask(Model model,@PathVariable Long taskId,@PathVariable Long projectId,@PathVariable Long userMemberId) {
	       
	        Task task=this.taskService.getTask(taskId);
	        User user=this.userService.getUser(userMemberId);
	        Project project=this.projectService.getProject(projectId);
	      
	      
	       
	        task.setUserTask(user);
	       
	        this.taskService.saveUser(user, task);
	      
	       
	           
	        //model.addAttribute("user",sessionData.getLoggedUser());
	       
	        model.addAttribute("project",project);   
	       
	        return "tasks";
	    }
	
}