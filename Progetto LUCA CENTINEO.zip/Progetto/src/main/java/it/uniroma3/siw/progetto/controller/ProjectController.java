package it.uniroma3.siw.progetto.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.progetto.controller.session.SessionData;
import it.uniroma3.siw.progetto.controller.validation.ProjectValidator;
import it.uniroma3.siw.progetto.model.Credentials;
import it.uniroma3.siw.progetto.model.Project;
import it.uniroma3.siw.progetto.model.Tag;
import it.uniroma3.siw.progetto.model.Task;
import it.uniroma3.siw.progetto.model.User;
import it.uniroma3.siw.progetto.service.CredentialsService;
import it.uniroma3.siw.progetto.service.ProjectService;
import it.uniroma3.siw.progetto.service.TaskService;
import it.uniroma3.siw.progetto.service.UserService;


@Controller
public class ProjectController {

	@Autowired
	ProjectService projectService;

	@Autowired
	UserService userService;

	@Autowired
	ProjectValidator projectValidator;

	@Autowired
	CredentialsService credentialsService;

	@Autowired
	SessionData sessionData;
	
	@Autowired
	TaskService taskService;

	@RequestMapping(value = { "/projects" }, method = RequestMethod.GET)
	public String myOwnedProjects(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		List<Project> projectsList = projectService.retrieveProjectsOwnedBy(loggedUser);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("projectsList", projectsList);
		return "projects";
	}

	@RequestMapping(value = { "/projects/{projectId}" }, method = RequestMethod.GET)
	public String project(Model model, @PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();

		Project project = projectService.getProject(projectId);
		if(project == null)
			return "redirect:/projects";

		List<User> members = userService.getMembers(project);
		if(!project.getOwner().equals(loggedUser) && !members.contains(loggedUser))
			return "redirect:/projects";

		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("members", members);

		return "project"; 	
	}

	@RequestMapping(value= { "/projects/add" }, method = RequestMethod.GET)
	public String createProjectForm(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("projectForm", new Project());
		return "addProject";
	}
	@RequestMapping(value= { "/projects/add" }, method = RequestMethod.POST)
	public String createProject(@Valid @ModelAttribute("projectForm") Project project,
			BindingResult projectBindingResult, Model model) {

		User loggedUser = sessionData.getLoggedUser();

		this.projectValidator.validate(project, projectBindingResult);
		if(!projectBindingResult.hasErrors()) {
			project.setOwner(loggedUser);
			this.projectService.saveProject(project);
			return "redirect:/projects/" + project.getId();
		}
		model.addAttribute("loggedUser", loggedUser);
		return "addProject";
	}

	@RequestMapping(value = { "/admin/users" }, method = RequestMethod.GET)
	public String userList(Model model) {

		User loggedUser = sessionData.getLoggedUser();
		List<Credentials> allCredentials = this.credentialsService.getAllCredentials();

		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("credentialsList", allCredentials);

		return "allUsers";
	}

	@RequestMapping(value = { "/admin/users/{username}/delete" }, method = RequestMethod.POST)
	public String removeUser(Model model, @PathVariable String username) {
		this.credentialsService.deleteCredentials(username);
		return "redirect:/admin/users";
	}

	@RequestMapping(value = { "projects/{projectId}/delete" }, method = RequestMethod.POST)
	public String removeProject(Model model, @PathVariable Long projectId) {
		this.projectService.deleteProject(projectId);
		return "redirect:/projects";
	}

	@RequestMapping(value= {"/sharedwith/{projectId}"},method=RequestMethod.GET)
	public String sharedWithPost(Model model,
			@PathVariable Long projectId) {

		String username=new String();
		User loggedUser=sessionData.getLoggedUser();
		Project project=projectService.getProject(projectId);
		if(project==null)
			return "redirect:/projects";


		model.addAttribute("username",username);
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("project",project);

		return "sharedWith";
	}


	@RequestMapping(value= {"/sharedwith/{projectId}"},method=RequestMethod.POST)
	public String sharedWith( @ModelAttribute("username")String username,@PathVariable Long projectId,
			Model model) {

		User loggedUser = sessionData.getLoggedUser();

		Project project = projectService.getProject(projectId);

		Credentials credentials = this.credentialsService.getCredentials(username);

		if(credentials!=null && !(project.getOwner().getUsername().equals(username))) {
			this.projectService.shareProjectWithUser(project, credentials.getUser());
			return "redirect:/projects/";
		}

		model.addAttribute("project",project);
		model.addAttribute("username",username);
		model.addAttribute("loggedUser",loggedUser);

		return "sharedWith";
	}

	@RequestMapping(value= {"/visibleProject"},method=RequestMethod.GET)    
	public String VisibleProjects(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		List<Project>projectsList=projectService.retrieveVisibleProjects(loggedUser);
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("projectsList",projectsList);

		return "visibleProject";

	}

	@RequestMapping(value= { "/editDescription/{projectId}" }, method = RequestMethod.GET)
	public String editDescriptionProjectForm(Model model, @PathVariable Long projectId) {
		Project project=projectService.getProject(projectId);
		model.addAttribute("project",project);

		return "editProjectDescription";
	}


	@RequestMapping(value= { "/editDescription/{projectId}" }, method = RequestMethod.POST)
	public String editDescriptionProject(Model model, @PathVariable Long projectId,
			@ModelAttribute("description")String description) {

		Project project=projectService.getProject(projectId);
		project.setDescription(description);
		this.projectService.saveProject(project);

		model.addAttribute("project",project);
		model.addAttribute("description",description);

		return "redirect:/projects";
	}

	@RequestMapping(value= { "/editName/{projectId}" }, method = RequestMethod.GET)
	public String editProjectForm(Model model, @PathVariable Long projectId) {
		Project project=projectService.getProject(projectId);
		model.addAttribute("project",project);

		return "editProjectName";
	}

	@RequestMapping(value= { "/editName/{projectId}" }, method = RequestMethod.POST)
	public String editProject(Model model, @PathVariable Long projectId,
			@ModelAttribute("name")String name) {

		Project project=projectService.getProject(projectId);
		project.setName(name);
		this.projectService.saveProject(project);

		model.addAttribute("project",project);
		model.addAttribute("name",name);

		return "redirect:/projects";
	}

	@RequestMapping(value= {"/addTag/{projectId}"}, method=RequestMethod.GET)
	public String createTag(Model model,@PathVariable Long projectId) {



		Project project=this.projectService.getProject(projectId);



		model.addAttribute("project",project);
		model.addAttribute("tagForm", new Tag());

		return  "addTag";
	}

	@RequestMapping(value= {"/addTag/{projectId}"}, method=RequestMethod.POST)
	public String createTagForm(@ModelAttribute("tagForm")Tag tag,
			Model model,@ModelAttribute("nameTag")String nome,
			@ModelAttribute("descriptionTag")String descrizione,
			@ModelAttribute("colorTag")String colore,
			@PathVariable Long projectId) {



		Project project = this.projectService.getProject(projectId);



		tag.setNome(nome);
		tag.setDescrizione(descrizione);
		tag.setColore(colore);
		this.projectService.saveTag(tag, project);



		model.addAttribute("user",sessionData.getLoggedUser());



		return "redirect:/projects";
	}

	@RequestMapping(value= {"/elenco/{projectId}"},method=RequestMethod.GET)
	public String elencoTask(Model model,
			@PathVariable Long projectId) {

		Project project = this.projectService.getProject(projectId);

		model.addAttribute("project",project);

		return "tasks";



	}


	@RequestMapping(value= {"/assegna/{taskId}/{projectId}"},method=RequestMethod.GET)
	public String assegnaTask(Model model,@PathVariable Long taskId,
			@PathVariable Long projectId) {


		User loggedUser=sessionData.getLoggedUser();
		Project project = this.projectService.getProject(projectId);
		Task task=this.taskService.getTask(taskId);


		List<User>members=this.userService.getMembers(project);



		model.addAttribute("userMemberList",members);

		model.addAttribute("project",project);

		model.addAttribute("task",task);

		return "assegnaTask";
	}



}
